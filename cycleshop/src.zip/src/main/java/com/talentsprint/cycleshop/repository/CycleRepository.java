package com.talentsprint.cycleshop.repository;

import org.springframework.data.repository.CrudRepository;

import com.talentsprint.cycleshop.entity.Cycle;

public interface CycleRepository extends CrudRepository<Cycle, Long>{
    
}
