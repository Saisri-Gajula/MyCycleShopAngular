package com.talentsprint.cycleshop.exception;

public class CycleShopBusinessException extends RuntimeException{
    public CycleShopBusinessException(String message) {
        super(message);
    }
}
