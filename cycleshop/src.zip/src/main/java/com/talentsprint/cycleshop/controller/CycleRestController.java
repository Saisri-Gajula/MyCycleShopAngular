package com.talentsprint.cycleshop.controller;

import java.util.List;

// import org.hibernate.mapping.List;
// import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.talentsprint.cycleshop.entity.Cycle;
// import com.talentsprint.cycleshop.repository.CycleRepository;
// import com.talentsprint.cycleshop.business.LoggedInUser;
// import com.talentsprint.cycleshop.business.NeedsAuth;
import com.talentsprint.cycleshop.service.CycleService;



@RestController
@RequestMapping("/api/cycle")
public class CycleRestController {

    @Autowired
    private CycleService cycleService;

    // @Autowired
    // private CycleRepository cycleRepository;

    // @Autowired
    // private LoggedInUser loggedInUser;
 
     @GetMapping("/{id}/borrow")
    public ResponseEntity<String> borrowCycle(@PathVariable long id, @RequestParam(required=false, defaultValue="1") int count) {
          cycleService.borrowCycle(id, count);
        //just a comment
       return new ResponseEntity<>("Borrow is happened",HttpStatus.OK);
    }

  
    @GetMapping("/{id}/return")
    public ResponseEntity<String> returnCycle(@PathVariable long id, @RequestParam(required=false, defaultValue="1") int count) {
        cycleService.returnCycle(id, count);
       return new ResponseEntity<>("returned a cycle",HttpStatus.OK);
    }

    @GetMapping("/{id}/restock/{quantity}")
    public ResponseEntity<String> restockCycle(@PathVariable long id, @PathVariable( name="quantity") int count) {
        cycleService.restockBy(id, count);
        return new ResponseEntity<>("restock is happened",HttpStatus.OK);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Cycle>> listAvailableCycles(Model model) {
        var allCycles = cycleService.listAvailableCycles();
        
        model.addAttribute("allCycles", allCycles);
        return new ResponseEntity<>(allCycles,HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<String> cycleDetail(@PathVariable long id, Model model) {
        var cycle = cycleService.findByIdOrThrow404(id);
        model.addAttribute("cycle", cycle);
        return new ResponseEntity<>("Cycle Details",HttpStatus.OK);
    }

    // @GetMapping("/add")
    // public ResponseEntity<String> addCycle(Model model){

    //     return 
    // }

    


}
